package lab;

import javafx.event.EventHandler;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;
import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class RandomCircle extends Circle {
	private double radius, width, height;
	private boolean captured;
	
	RandomCircle(double width, double height) {
		super();
		double rand= Math.random()*50+20;
		this.radius= rand;
		setRadius(radius);
		this.width= width;
		this.height= height;
		double randR= Math.random()*255, randG= Math.random()*255, randB= Math.random()*255;
		this.setFill(Color.rgb((int)randR, (int)randG, (int)randB));
		captured= false;
		TranslateTransition trans= new TranslateTransition(new Duration(1500), this);
		trans.setFromX(randomCoord(width));
		trans.setFromY(randomCoord(height));
		trans.setToX(randomCoord(width));
		trans.setToY(randomCoord(height));
		trans.setCycleCount(Animation.INDEFINITE);
		trans.setAutoReverse(true);
		trans.play();
		
		setOnMousePressed(event -> {
			trans.stop();
			captured= true;
			trans.setFromX(event.getSceneX());
			trans.setFromY(event.getSceneY());
			trans.setToX(width/2);
			trans.setToY(height/2);
			trans.setAutoReverse(false);
			trans.setCycleCount(1);
			trans.play();
			setOnMousePressed(null);
		});
			
		
	}
	
	double randomCoord(double range) {
		double rand= Math.random()*range;
		if(rand + radius > range) {
			rand= range - radius;
		}
		else if(radius > rand) {
			rand= radius;
		}
		return rand;
	}
	
	boolean isCaptured() {
		return captured;
	}

}
