package lab;
import java.util.ArrayList;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import javafx.animation.Timeline;

/**
 * Name: Shaurya Beriwala
 * Username: beris01
 */

public class Controller {
	
	@FXML
    private Pane pane;
	
	@FXML
    private Button playBtn;

    @FXML
    private Label rulesLbl1;

    @FXML
    private Label rulesLbl2;

    @FXML
    private Label winLbl;
    
    @FXML
    private VBox startBox;

    
    private double width, height;

	/*private EventHandler<ActionEvent> clickEvent = event -> {
		myCircle.setCenter(width/2);
	};*/

    
    @FXML
    void initialize() {
    	Timeline checkGameOver = new Timeline(new KeyFrame(Duration.millis(500), e -> {
			if (!pane.getChildren().contains(startBox)) {
				for (Node n: pane.getChildren()) {
					RandomCircle rc = (RandomCircle)n;
					if (!rc.isCaptured()) {
						return; //Stop if any are yet to be captured
					}
					System.out.println(rc.isCaptured());
				}
				//All are captured, end the game
				winLbl.setVisible(true);
				playBtn.setVisible(true);
				pane.getChildren().add(startBox);
			}

		}));
		checkGameOver.setCycleCount(Animation.INDEFINITE);
		checkGameOver.play();
    	/*Timeline checkGameOver= new Timeline(new KeyFrame(Duration.millis(500), e -> {
    		if(!pane.getChildren().contains(winLbl)) {
    			for(Node n : pane.getChildren()) {
    				RandomCircle rc= (RandomCircle)n;
    				
    				if(!rc.isCaptured()) {
    					return;
    				}
    				System.out.println(rc.isCaptured());
    			}
    			winLbl.setVisible(true);
    			rulesLbl1.setVisible(true);
    	    	rulesLbl2.setVisible(true);
    	    	playBtn.setVisible(true);
    		}
    	}));
    	checkGameOver.setCycleCount(Animation.INDEFINITE);
    	checkGameOver.play();*/
    }

    @FXML
    void startGame(ActionEvent event) {
    	width= pane.getWidth();
    	height= pane.getHeight();
    	pane.getChildren().clear();
    	for(int i=0; i<5; i++) {
    		RandomCircle myCircle= new RandomCircle(width, height);
    		pane.getChildren().add(myCircle);
    		//myCircle.addEventHandler(MouseEvent.MOUSE_CLICKED, clickEvent);
    	}
    }

}


























